package com.fmp.mediaplayer.service

import com.fmp.mediaplayer.config.ServiceConfig
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.core.io.ByteArrayResource
import org.springframework.core.io.support.ResourceRegion
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.stereotype.Service
import org.springframework.web.reactive.function.server.ServerRequest
import org.springframework.web.reactive.function.server.ServerResponse
import reactor.core.publisher.Mono
import java.io.File
import java.io.RandomAccessFile
import java.lang.Long.min


interface StreamingService {

    fun streamAudio(request: ServerRequest): Mono<ServerResponse>

}


@Service
class StreamingServiceImpl(private val config: ServiceConfig) : StreamingService {

    private val log = logger()


    override fun streamAudio(request: ServerRequest): Mono<ServerResponse> {

        log.trace("---> {} {}", "GET", "/api/v1/playSong")

        val songId = request.queryParam("songId")
                .orElseThrow { RuntimeException("song not found") }

        val filePath = "${config.contentDir}/$songId.mp3"

        val contentLength = File(filePath).length()
        val requestHeaders = request.headers().asHttpHeaders()

        val start = getStartRange(contentLength, requestHeaders)
        val rangeLength = getRangeLength(contentLength, requestHeaders)
        val status = if (isPartialContent(rangeLength, requestHeaders)) HttpStatus.PARTIAL_CONTENT else HttpStatus.OK

        val bytes = getBytes(filePath, start, rangeLength.toInt())

        val resource = ByteArrayResource(bytes)
        val resourceRegion = ResourceRegion(resource, 0, rangeLength)

        return ServerResponse.status(status)
                .contentType(MediaType.parseMediaType("audio/mp3"))
                .contentLength(contentLength)
                .body(Mono.just(resourceRegion), ResourceRegion::class.java)
    }

    private fun isPartialContent(rangeLength: Long, requestHeaders: HttpHeaders): Boolean {

        return requestHeaders.range.isNotEmpty() || rangeLength > config.chunkSize.toLong()
    }

    private fun getStartRange(contentLength: Long, requestHeaders: HttpHeaders): Long {

        return if (requestHeaders.range.isNotEmpty()) {

            val range = requestHeaders.range[0]

            log.debug("contentLength: {} - range: {}", contentLength, range)
            range.getRangeStart(contentLength)

        } else 0
    }

    private fun getRangeLength(contentLength: Long, requestHeaders: HttpHeaders): Long {

        var rangeLength = contentLength
        val chunkSize = config.chunkSize.toLong()

        if (requestHeaders.range.isNotEmpty()) {

            val range = requestHeaders.range[0]

            val start = range.getRangeStart(contentLength)

            val end = range.getRangeEnd(contentLength)
            rangeLength = end - start + 1

            log.debug("start: {} - end: {} - range: {}", start, end, range)
        }

        return min(chunkSize, rangeLength)
    }

    private fun getBytes(filePath: String, from: Long, length: Int): ByteArray {

        log.debug("filePath: {} - from: {} - length: {}", filePath, from, length)

        val buffer = ByteArray(config.chunkSize)

        val raf = RandomAccessFile(filePath, "r")
        raf.seek(from)
        raf.read(buffer, 0, length)

        return buffer
    }

}


inline fun <reified T> T.logger(): Logger {
    return LoggerFactory.getLogger(T::class.java)
}