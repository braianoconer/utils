package com.fmp.mediaplayer.config

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "service")
class ServiceConfig {

	var chunkSize: Int = 524288
	lateinit var contentDir: String

}